package com.example.camping.dto;

import lombok.Getter;
import lombok.Setter;

@Getter @Setter
public class BookCampDTO {
	private String address;
	private String camp_title;
	private int count;

}
