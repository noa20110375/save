package com.example.camping.repository;


import java.util.List;

import org.apache.ibatis.annotations.Param;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.example.camping.model.Camping;

public interface CampingRepository extends JpaRepository<Camping, Long>{
	@Query(value="select * From camping where address like CONCAT('%',:address,'%')"
			+ "and camp_title like CONCAT('%',:camp_title,'%')"
			+ "and count not like CONCAT('%',:count,'%')",
			nativeQuery=true)
	public List<Camping> Search(@Param("address")String address, @Param("camp_title")String camp_title,@Param("count")int count);
}
