package com.example.camping.jwt;

import java.io.IOException;

import javax.servlet.FilterChain;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.web.filter.OncePerRequestFilter;

import com.auth0.jwt.JWT;
import com.auth0.jwt.algorithms.Algorithm;
import com.auth0.jwt.exceptions.JWTVerificationException;
import com.auth0.jwt.exceptions.TokenExpiredException;
import com.example.camping.repository.OAuthRepository;

import lombok.RequiredArgsConstructor;

//(1)
@RequiredArgsConstructor
@Component
public class JwtRequestFilter extends OncePerRequestFilter {

  @Autowired //(2)
  OAuthRepository oauthRepository;

@Override
protected void doFilterInternal(HttpServletRequest request, HttpServletResponse response, FilterChain filterChain)
		throws ServletException, IOException {
	
	 String jwtHeader = ((HttpServletRequest)request).getHeader(jwtProperties.HEADER_STRING);

	 if(jwtHeader == null || !jwtHeader.startsWith(jwtProperties.TOKEN_PREFIX)) {
         filterChain.doFilter(request, response);
         return;
     }
	 String token = jwtHeader.replace(jwtProperties.TOKEN_PREFIX, "");

     Long userCode = null;

     try {
         userCode = JWT.require(Algorithm.HMAC512(jwtProperties.SECRET)).build().verify(token)
                 .getClaim("id").asLong();

     } catch (TokenExpiredException e) {
         e.printStackTrace();
         request.setAttribute(jwtProperties.HEADER_STRING, "토큰이 만료되었습니다.");
     } catch (JWTVerificationException e) {
         e.printStackTrace();
         request.setAttribute(jwtProperties.HEADER_STRING, "유효하지 않은 토큰입니다.");
     }
     
     request.setAttribute("userCode", userCode);

		
     filterChain.doFilter(request, response);
}

 
}