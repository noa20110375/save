package com.example.camping.config.auth;

import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;

import com.example.camping.model.Member;
import com.example.camping.model.User;
import com.example.camping.repository.MemberRepository;
import com.example.camping.repository.OAuthRepository;

@Service
public class PrincipalDetails2 implements UserDetailsService {
	@Autowired
	private MemberRepository memberRepository;
	@Autowired
	private OAuthRepository oAuthRepository;
	
	
	@Override
	public UserDetails loadUserByUsername(String kakaoNickname) throws UsernameNotFoundException {
		System.out.println("loadUserByUsername");
		User user = oAuthRepository.findByKakaoNickname(kakaoNickname);
		if(user==null)return null;
		
		PrincipalAuth pusercode= new PrincipalAuth(user);
		System.out.println("pusercode:"+pusercode);
		return pusercode;
	}
	
}
