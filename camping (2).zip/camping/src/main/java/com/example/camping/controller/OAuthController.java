package com.example.camping.controller;

import java.util.HashMap;

import javax.net.ssl.HttpsURLConnection;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.http.HttpHeaders;


import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

import com.example.camping.jwt.jwtProperties;
import com.example.camping.model.OAuthToken;
import com.example.camping.model.User;
import com.example.camping.service.OAuthService;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;

import lombok.AllArgsConstructor;



@RestController

public class OAuthController {

	@Autowired
    private OAuthService oauthService;
	private String jwtToken; 
	
	
	@GetMapping("/auth/kakao/callback")
	@ResponseBody
    public ResponseEntity<String>  getLogin(@RequestParam("code") String code) {
//    
		 
	       OAuthToken oauthToken = oauthService.getAccessToken(code);
	   
	       String User = oauthService.saveUserAndGetToken(oauthToken.getAccess_token());
	       HttpHeaders headers = new HttpHeaders();
	       headers.add(jwtProperties.HEADER_STRING, jwtProperties.TOKEN_PREFIX  + jwtToken);
	       
	       
	       return ResponseEntity.ok().headers(headers).body("/user/login");
	}
	
	
	@GetMapping("/me")
    public ResponseEntity<Object> getCurrentUser(HttpServletRequest request) { //(1)

		//(2)
        User user = oauthService.getUser(request);
        
		//(3)
        return ResponseEntity.ok().body(user);
    }






	@RequestMapping(value = "/auth/kakao/logout")
	@ResponseBody
public String logout(@RequestParam HttpSession session) {
	
		return "/user/login";

	}

}