package com.example.camping.controller;


import javax.servlet.http.HttpSession;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.ResponseBody;

import com.example.camping.model.Member;
import com.example.camping.repository.MemberRepository;
import com.example.camping.service.MemberService;

import lombok.RequiredArgsConstructor;

@Controller
@RequiredArgsConstructor
public class HomeController {
	
	private final MemberService memberService;
	private final MemberRepository memberRepository;
	
	@GetMapping("/")
	public String home() {
		return "/board/index";
		//return "/booking/bookingForm";
	}
	//濡쒓렇�씤
	@GetMapping("/login")
	public String login() {
		return "/user/login";
	}
	//愿�由ъ옄 濡쒓렇�씤
	@GetMapping("/adminlogin")
	public String adminlogin() {
		return "/user/adminlogin";
	}
	//�쉶�썝媛��엯�뤌
	@GetMapping("/join")

	public String join() {
		return "/user/join";
	}
	//�쉶�썝媛��엯
	@PostMapping("/join")
	@ResponseBody
	public String join(@RequestBody Member member) {
		
		memberService.join(member);
		return "success";
	}
	//�쉶�썝�닔�젙�뤌
	@GetMapping("update")
	public String update() {
		return "/user/update";
	}
	////�쉶�썝�닔�젙�뤌
	@PutMapping("update/{id}")
	@ResponseBody
	public String update(@RequestBody Member member,
			HttpSession session) {
		memberService.update(member);
		session.invalidate();
		return "success";
	}
	@DeleteMapping("/delete/{id}")
	@ResponseBody
	public String delete(@PathVariable Long id) {
		memberService.delete(id);
		return "success";
	}
	//�삁�빟�뤌
	@GetMapping("/bookingForm")
	public String bookingForm() {
		return "/booking/bookingForm";
	}
	//�긽�꽭蹂닿린
	@GetMapping("/detail")
	public String detail() {
		return "/user/detail";
	}
	
	
}
