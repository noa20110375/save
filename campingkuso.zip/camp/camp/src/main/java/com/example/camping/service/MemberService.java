package com.example.camping.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.example.camping.model.Member;
import com.example.camping.repository.MemberRepository;

@Transactional
@Service
public class MemberService {

	
	@Autowired
	private BCryptPasswordEncoder encoder;
	
	@Autowired
	private MemberRepository memberRepository;
	//회원가입
	@Transactional
	public void join(Member member) {
		String rawPassword = member.getPassword();
		String encPassword = encoder.encode(rawPassword);
		member.setPassword(encPassword);// 암호화 된 비번
		memberRepository.save(member);
	}
	//회원정보 수정
	
	@Transactional
	public void update(Member member ) {
		Member persistance = memberRepository.findById(member.getId()).get();
		String rawPassword = member.getPassword();
		String encPassword = encoder.encode(rawPassword);
		persistance.setPassword(encPassword);
		persistance.setEmail(member.getEmail());
		
		
		}

	//회원탈퇴
	@Transactional
	public void delete(Long id) {
		memberRepository.deleteById(id);
		//boardRepository.deleteByNum(num);
			
	}
}
