package com.example.camping.config.auth;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;

import com.example.camping.model.Member;
import com.example.camping.model.User;
import com.example.camping.repository.MemberRepository;
import com.example.camping.repository.OAuthRepository;


@Service
public class PrincipalDetails implements UserDetailsService{
 
	@Autowired
	private MemberRepository memberRepository;
	@Autowired
	private OAuthRepository oAuthRepository;
	@Override
	public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
		System.out.println("loadUserByUsername");
		Member member = memberRepository.findByUsername(username);
		if(member==null)return null;
		//�쉶�썝�씠�씪硫� �떆�걧由ы떚媛� �쟻�슜�맂 User 由ы꽩
		PrincipalMember puser= new PrincipalMember(member);
		System.out.println("puser:"+puser);
		return puser;
	}
	public UserDetails loadUserBykakaoNickname(Long userCode) throws UsernameNotFoundException {
		System.out.println("loadUserByUsername");
		User user = oAuthRepository.findByUserCode(userCode);
		if(userCode==null)return null;
		//�쉶�썝�씠�씪硫� �떆�걧由ы떚媛� �쟻�슜�맂 User 由ы꽩
		PrincipalAuth pusercode= new PrincipalAuth(user);
		System.out.println("pusercode:"+pusercode);
		return pusercode;
	}
	
}
