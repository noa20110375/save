package com.example.camping.model;

import javax.persistence.Column;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

public class User {
	@Id @GeneratedValue(strategy = GenerationType.IDENTITY)
  private int id ;//������,auto_increment
	@Column(nullable =false, length=30, unique =true)
	private String username;
	
	
	private String email;
}
 