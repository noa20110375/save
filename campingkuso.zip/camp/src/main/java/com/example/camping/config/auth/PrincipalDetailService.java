package com.example.camping.config.auth;

import com.example.camping.model.Member;

public class PrincipalDetailService {

	
	
	
	public PrincipalDetailService(Member member) {
	 
 }
}
