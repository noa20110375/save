package com.example.camping.controller;

import java.util.HashMap;

import javax.net.ssl.HttpsURLConnection;
import javax.servlet.http.HttpSession;

import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.RequestEntity;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import org.springframework.web.bind.annotation.GetMapping;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import org.springframework.web.client.RestTemplate;

import com.example.camping.model.OAuthToken;
import com.example.camping.service.OAuthService;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;



@Controller


public class OAuthController {

	/**
     * īī�� callback
     * [GET] /oauth/kakao/callback
     */
	
	@GetMapping("/auth/kakao/callback")
	@ResponseBody//Data�� �������ִ� ��Ʈ�ѷ� �Լ�.
    public String  kakaoCallback(@RequestParam String code,HttpSession session) {
//        System.out.println(code);
//        String access_Token = OAuthService.getKakaoAccessToken(code);
//        System.out.println("access_Token : " + access_Token);
//        HashMap<String, Object> userInfo = OAuthService.getUserInfo(access_Token);
//        System.out.println("login Controller : " + userInfo);
//        if (userInfo.get("email") != null) {
//            session.setAttribute("userId", userInfo.get("email"));
//            session.setAttribute("access_Token", access_Token);
//        }
		
		//POST������� key=value �����͸� ��û(īī��������)
		
		RestTemplate rt = new RestTemplate();
		
		//HttpHeader ������Ʈ ����
		HttpHeaders headers= new HttpHeaders();
		headers.add("Content-type","application/x-www-form-urlencoded;charset=utf-8");
		
		
		//HttpBody ������Ʈ ���� 
		MultiValueMap<String,String>params = new LinkedMultiValueMap<>();
		params.add("grant_type","authorization_code");
		params.add("client_id","25e9068a898c848763a0508296b6cc0b");
		params.add("redirect_uri","http://localhost:7800/auth/kakao/callback");
		params.add("code",code);
		
		
		//HttpHeader�� HttpBody�� �ϳ��� ������Ʈ�� ���� 
		//body,header ���� ������ entity
		HttpEntity<MultiValueMap<String, String>> kakaoTokenRequest=
				new HttpEntity<>(params,headers);
		
		//Http��û�ϱ� - post��� - response ������ ���� ����.
		ResponseEntity<String> response =rt.exchange(
				"https://kauth.kakao.com/oauth/token",
				HttpMethod.POST,
				kakaoTokenRequest,
				String.class
			
			
		);
		
		
		ObjectMapper objectMapper = new ObjectMapper();
		OAuthToken oauthToken = null;
		try {
			oauthToken = objectMapper.readValue(response.getBody(),OAuthToken.class);
		} catch (JsonMappingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (JsonProcessingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} 
		 
		//������ �ڵ�� ��������ū�� �ο� ���� ����
		System.out.println("īī�� ��������ū:"+oauthToken.getAccess_token());
        
		RestTemplate rt2 = new RestTemplate();
		
		//HttpHeader ������Ʈ ����

		
		HttpHeaders headers2= new HttpHeaders();
		
		headers2.add("Authorization","Bearer"+oauthToken.getAccess_token());
		headers2.add("Content-type","application/x-www-form-urlencoded;charset=utf-8");
		
		
		
		//HttpHeader�� HttpBody�� �ϳ��� ������Ʈ�� ���� 
		//body,header ���� ������ entity
		HttpEntity<MultiValueMap<String, String>> kakaoProfileRequest2=
				new HttpEntity<>(headers2);
		
		//Http��û�ϱ� - post��� - response ������ ���� ����.
		ResponseEntity<String> response2 =rt2.exchange(
				"https://kapi.kakao.com/v2/user/me",
				HttpMethod.POST,
				kakaoProfileRequest2,
				String.class
			
			
		);
		
		return response2.getBody();
    }

	
	
	
	
	
	







	@RequestMapping(value = "/logoutt")
	public String logout(HttpSession session) {
		String access_Token = (String) session.getAttribute("access_Token");

		if (access_Token != null && !"".equals(access_Token)) {
			OAuthService.kakaoLogout(access_Token);
			session.removeAttribute("access_Token");
			session.removeAttribute("userId");
		} else {
			System.out.println("access_Token is null");
			// return "redirect:/";
		}
		// return "index";
		return "/user/login";

	}

}